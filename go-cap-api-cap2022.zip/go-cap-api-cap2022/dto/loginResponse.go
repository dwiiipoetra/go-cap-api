package dto

type LoginResponse struct {
	AccessToken string `json:"access_token"`
}
