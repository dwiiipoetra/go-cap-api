package dto

type NewAccountResponse struct {
	AccountID string `json:"account_id"`
}
